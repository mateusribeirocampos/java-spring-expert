package com.devsuperior.dscatalog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DscatalogApplicationTests {

	@Test
	void contextLoads() {
	}

}
